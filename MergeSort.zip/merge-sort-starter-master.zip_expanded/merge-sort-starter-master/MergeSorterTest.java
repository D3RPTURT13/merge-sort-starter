import static org.junit.Assert.*;

import org.junit.Test;

public class MergeSorterTest {

	@Test
	public void testReverse(){
		// fail("Not yet implemented");
	}
	
	@Test
	public void testMergeSort() {
		int[] test1 = {1, 2, 3, 4, 5, 6, 7};
		assertTrue(MergeSorterTest.MergeSort(test1) == 7;
		
		int[] test2 = {10, 8, 2, 1};
		assertTrue(MergeSorterTest.MergeSort(test2) == 10);
	}

}