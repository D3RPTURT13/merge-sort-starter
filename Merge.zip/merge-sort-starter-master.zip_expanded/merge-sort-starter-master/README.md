# merge-sort-starter
This repo contains the starter code for the merge sort lab.
