
public class MergeSorter {
	public static void mergeSort(int list[], int hi, int lo) {
      int r = 0;
        int n1 = lo - hi + 1;
        int n2 = r - lo;
 
        int L[] = new int [n1];
        int R[] = new int [n2];
 
       
        for (int i=0; i<n1; ++i)
            L[i] = list[hi + i];
        for (int j=0; j<n2; ++j)
            R[j] = list[lo + hi+ j];
 
 
      
        int i = 0, j = 0;
 
      
        int k = hi;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                list[k] = L[i];
                i++;
            } else {
                list[k] = R[j];
                j++;
            }
            k++;
        }
 
       
        while (i < n1) {
            list[k] = L[i];
            i++;
            k++;
        }
 
        
        while (j < n2) {
            list[k] = R[j];
            j++;
            k++;
        }
    }
 
   
    void merge(int list[], int l, int r) {
        if (l < r) {
     
            int m = (l+r)/2;
 
            merge(list, l, m);
            merge(list , m+1, r);
 
        }
    }
 
   
}
